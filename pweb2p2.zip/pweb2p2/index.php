<?php include 'db.php'; ?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Website Kursus</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .carousel-container {
            width: 40%;
            height: 40%;
        }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <div class="container d-flex justify-content-center mt-4">
        <div id="carouselExample" class="carousel slide carousel-container">
            <div class="carousel-inner">
                <?php
                $result = $conn->query("SELECT * FROM courses");
                $active = "active";
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='carousel-item $active text-center'>
                        <img src='" . $row['image_url'] . "' class='d-block w-100 rounded' alt='" . $row['name'] . "'>
                       <div class='carousel-caption d-none d-md-block bg-dark bg-opacity-50 p-3 rounded'>
                            <h5 class='mb-2'>" . $row['name'] . "</h5>
                            <p class='mb-0'>" . $row['description'] . "</p>
                        </div>
                      </div>";
                    $active = "";
                }
                ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>